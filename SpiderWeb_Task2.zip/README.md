Overview
========

This is a front end tic tac toe game, built to have a responsive UI.
The game needs JavaScript to run, if that wasn't obvious before.
Please use a modern browser like Chrome for Firefox for best results.

Contact
=======

Name: Siddarth R Iyer
Spider Handle: Mindstormer619
Roll No: 106113089